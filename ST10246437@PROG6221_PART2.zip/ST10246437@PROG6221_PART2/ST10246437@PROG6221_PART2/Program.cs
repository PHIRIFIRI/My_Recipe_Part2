﻿using RecipeMaker;

internal class Program
{
    //The following class recipe has been instantiated
    static List<Recipe> recipes = new List<Recipe>();

    private static void Main(string[] args)
    {
        //The code is a menu which prompts the user to choose options below
        Console.WriteLine("************************************************************************");
        Console.WriteLine("*********************** W E L C O M E!!!...*****************************");
        Console.WriteLine("************************************************************************");
        Console.WriteLine("Please follow the instructions & Create your own meal from start........");
        Console.WriteLine("************************************************************************");
        Console.WriteLine("************************************************************************");
        while (true)
        {
            Console.WriteLine("************************************************************************");
            Console.WriteLine("\nSelect an option :************************************************");
            Console.WriteLine("********************************************************************");
            Console.WriteLine("1. Add a recipe : **************************************************");
            Console.WriteLine("2. List all recipes : **********************************************");
            Console.WriteLine("3. View a recipe : *************************************************");
            Console.WriteLine("4. Exit : **********************************************************");
            Console.WriteLine("********************************************************************");
            Console.WriteLine("********************* T H A N K - Y O U ****************************");
            Console.WriteLine("********************************************************************");

            string option = Console.ReadLine();
            //i have used a switch statement to loop through our menu
            switch (option)
            {
                case "1":
                    AddRecipe();
                    break;
                case "2":
                    ListRecipes();
                    break;
                case "3":
                    ViewRecipe();
                    break;
                case "4":
                    Console.WriteLine("Thank you for using the recipe app. Goodbye!");
                    return;
                    // error handling for wrong input
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }

    static void AddRecipe()//The following is the method for adding a recipe
    {
        
        Console.WriteLine("******************************************************************");
        Console.WriteLine("\nAdding a new recipe");
        Console.WriteLine("******************************************************************");
        Console.Write("Enter the name of the recipe: ");
        Console.WriteLine("******************************************************************");
        string name = Console.ReadLine();
        //setting the name of the recipe
        Recipe recipe = new Recipe();
        recipe.Name = name;
        Console.WriteLine("******************************************************************");
        Console.Write("Enter the number of ingredients: ");
        Console.WriteLine("******************************************************************");
        int numIngredients = int.Parse(Console.ReadLine());
        //using for each loop to enter unlimited values to store
        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine("******************************************************************");
            Console.WriteLine($"\nIngredient :{i + 1}");
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the name: ");
            string ingredientName = Console.ReadLine();
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the unit: ");
            string unit = Console.ReadLine();
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the calories : ");
            int calories = int.Parse(Console.ReadLine());
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the food group : ");
            Console.WriteLine("******************************************************************");
            string foodGroup = Console.ReadLine();
            //adding values with get and set to store in out ingredients
            recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
        }
        Console.WriteLine("******************************************************************");
        Console.Write("Enter the number of steps : ");
        int numSteps = int.Parse(Console.ReadLine());
        Console.WriteLine("******************************************************************");

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine("******************************************************************");
            Console.WriteLine($"\nStep  {i + 1}");
            Console.WriteLine("******************************************************************");
            Console.Write("Enter the description of recipe: ");
            string description = Console.ReadLine();
            Console.WriteLine("******************************************************************");

            recipe.AddStep(description);
        }

        recipes.Add(recipe);
        Console.WriteLine($"Recipe '{name}' has been added successfully!");
    }

    static void ListRecipes()//This is the method to list out recipe available
    {
        //if statement used to check if we have recipes stored in memory
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes found.");
            return;
        }
        Console.WriteLine("******************************************************************");
        Console.WriteLine("\nList of Recipes:");
        Console.WriteLine("******************************************************************");
        List<Recipe> sortedRecipes = recipes.OrderBy(r => r.Name).ToList();
        //List of recipes stores and now being ordered by name and loop through to display results
        foreach (Recipe recipe in sortedRecipes)
        {
            Console.WriteLine(recipe.Name);
        }
    }

    static void ViewRecipe()//method to view our recipe
    {
        Console.WriteLine("******************************************************************");
        Console.Write("\nEnter the name of the recipe: ");
        Console.WriteLine("******************************************************************");
        string name = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        //Calculation of calories
        Console.WriteLine($"\nRecipe: {recipe.Name}");
        recipe.Print();
        double totalCalories = recipe.CalculateTotalCalories();
        Console.WriteLine($"\nTotal Calories: {totalCalories}");

        recipe.NotifyCaloriesExceeded();
    }
}
