﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeMaker
{
    class Recipe
        //outter class recipe 
    {
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }
        public string? Name { get; internal set; }

        public Recipe()//items to store within out ingredients and steps
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public Recipe(List<string> steps) => Steps = steps;

        public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            //AddIngredient values to ingredient
            Ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
        }
        // method to add description to steps
        public void AddStep(string description)
        {
            Steps.Add(description);
        }

        public void Print()//Method to print items and values stored
        {
            Console.WriteLine("******************************************************************");
            Console.WriteLine("Ingredients:");
            Console.WriteLine("******************************************************************");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
            }
            Console.WriteLine("******************************************************************");
            Console.WriteLine("\nSteps:");
            Console.WriteLine("******************************************************************");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

       //Method to calculate calories
        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        public void NotifyCaloriesExceeded()//Method for error handling in calories
        {
            double totalCalories = CalculateTotalCalories();
            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories.");
            }
        }

        public void Scale(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
        }

        public void Clear()
        {
            Ingredients.Clear();
            Steps.Clear();
        }

    }
}

